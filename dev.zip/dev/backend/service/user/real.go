package userservice

import "github.com/Mateus-MS/Gole-Certo/dev/backend/domain/user"

type service struct {
}

func New() *service {
	return &service{}
}

func (s *service) Register(usr user.User) (err error) {
	return err
}

func (s *service) Search(identifier string) (usr user.User, err error) {
	return usr, err
}
